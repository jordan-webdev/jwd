<?php
/*
 * Create the FAQ custom post type, FAQ Category custom taxonomy and custom terms
 */

 function jwd_set_faq_action()
 {
    add_option( 'faq_cpt', 1 );

    wp_insert_term(
      'All',
      'faq_category',
      $args = array(
        'description' => 'All FAQ Categories',
        'slug' => 'all',
      )
    );

    $parent_term = term_exists( 'all', 'faq_category' ); // array is returned if taxonomy is given
    $parent_id = $parent_term['term_id'];

    $i = 1;

    while ($i <= 6){

      $slug = 'faq_category_' . $i;
      $tax = 'faq_category';

      wp_insert_term(
        'FAQ Category '. $i,
        $tax,
        $args = array(
          'description' => 'Sample FAQ Category',
          'slug' => $slug,
          'parent' => $parent_id,
        )
      );

      // Create post object
      $content = "Lorem Ipsum > FAQ > This FAQ > WYSIWYG Lorem Ipsum > FAQ > This FAQ > WYSIWYG Lorem Ipsum > FAQ > This FAQ > WYSIWYG Lorem Ipsum > FAQ > This FAQ > WYSIWYG Lorem Ipsum > FAQ > This FAQ > WYSIWYG";
      $term_id = get_term_by('slug', $slug, $tax)->term_id;
      $tax_input = array(
        'faq_category' => array(
          $term_id
        ),
      );
      $sample_post = array(
        'post_title'    => 'FAQ Post ' . $i,
        'post_content'  => $content,
        'post_type' => 'faq',
        'post_status'   => 'publish',
        'tax_input' => $tax_input
      );

      // Insert the post into the database
      wp_insert_post( $sample_post );

      $i++;
    }

     echo '<div id="message" class="updated fade"><p>'
     .'FAQ Added.' . '</p></div>';
 }
