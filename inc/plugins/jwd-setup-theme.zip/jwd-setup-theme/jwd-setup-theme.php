<?php
/**
 * Plugin Name: JWD Theme Setup
 * Description: Adds custom post types, custom taxonomy and custom terms to the theme
 * Version: 1.0
 * Author: Jordan Webdev
 * Author URI: www.jordanwebdev.com
 */

add_action('admin_menu', 'jwd_theme_setup_menu');

function jwd_theme_setup_menu()
{
    add_menu_page('Theme Setup', 'Theme Setup', 'manage_options', 'jwd-theme-setup', 'jwd_theme_setup_admin_page');
}

function jwd_theme_setup_admin_page()
{

  // This function creates the output for the admin page.
  // It also checks the value of the $_POST variable to see whether
  // there has been a form submission.

  // The check_admin_referer is a WordPress function that does some security
  // checking and is recommended good practice.

  // General check for user permissions.
  if (!current_user_can('manage_options')) {
      wp_die(__('You do not have sufficient pilchards to access this page.'));
  }

  // Start building the page

  echo '<div class="wrap">';

    echo '<h2>Theme Setup</h2>';

      // Check whether the button has been pressed AND also check the nonce
      if (isset($_POST['jwd_set_faq_button']) && check_admin_referer('jwd_set_faq_button_clicked')) {
          // the button has been pressed AND we've passed the security check
        jwd_set_faq_action();
      }

    echo '<form action="options-general.php?page=jwd-theme-setup" method="post">';

      // this is a WordPress security feature - see: https://codex.wordpress.org/WordPress_Nonces
      wp_nonce_field('jwd_set_faq_button_clicked');
      echo '<input type="hidden" value="true" name="jwd_set_faq_button" />';
      submit_button('Add FAQ');
    echo '</form>';

  echo '</div>';
}

$dir = plugin_dir_path( __FILE__ );
require $dir . '/faq.php';
